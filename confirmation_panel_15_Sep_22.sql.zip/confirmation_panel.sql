-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 15, 2022 at 10:53 AM
-- Server version: 8.0.30-0ubuntu0.20.04.2
-- PHP Version: 8.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `confirmation_panel`
--
CREATE DATABASE IF NOT EXISTS `confirmation_panel` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `confirmation_panel`;

-- --------------------------------------------------------

--
-- Table structure for table `company_locations`
--

DROP TABLE IF EXISTS `company_locations`;
CREATE TABLE `company_locations` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `company_locations`
--

TRUNCATE TABLE `company_locations`;
--
-- Dumping data for table `company_locations`
--

INSERT INTO `company_locations` (`id`, `name`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Gurugram - AIHP', '0', '1', '2022-08-05 05:05:39', '2022-08-17 11:13:29'),
(2, 'Mohali', '0', '1', '2022-08-05 05:05:39', '2022-08-05 05:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `company_names`
--

DROP TABLE IF EXISTS `company_names`;
CREATE TABLE `company_names` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `company_names`
--

TRUNCATE TABLE `company_names`;
--
-- Dumping data for table `company_names`
--

INSERT INTO `company_names` (`id`, `name`, `logo`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'BVC eServices Pvt Ltd', '/storage/app/all-company-logos/tFqDqXIzD3klTYscuTmIGSnmb6HIUEwxsSwAHvxr.png', '0', '1', NULL, '2022-09-05 09:13:55'),
(2, 'vCommission Media Pvt Ltd', '/storage/app/all-company-logos/bbZ991bPrevY2gHwUSJtosdUqXWED4WURPqxLf10.png', '0', '1', NULL, '2022-09-05 09:16:05'),
(3, 'Adways VC India Pvt Ltd', NULL, '0', '1', NULL, '2022-08-17 11:12:09'),
(4, 'Nutrfy', NULL, '0', '1', NULL, NULL),
(5, 'Letx', NULL, '0', '1', NULL, NULL),
(6, 'Vfullfill', NULL, '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_feedback_forms`
--

DROP TABLE IF EXISTS `confirmation_feedback_forms`;
CREATE TABLE `confirmation_feedback_forms` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `manager_id` bigint UNSIGNED NOT NULL,
  `discipline` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `punctuality` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `work_ethics` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `team_work` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `response_towards_feedback` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `elaborate_performance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_highlights_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_highlights_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_highlights_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `major_task_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `major_task_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `major_task_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_value_in_team` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `add_value_in_team_share_instance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `areas_of_improvement_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `areas_of_improvement_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `areas_of_improvement_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `met_your_expectations` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `met_your_expectations_other_specify` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `are_you_sure_to_confirm` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommend_pip_detailed_plan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `increment_on_confirmation` enum('Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `mention_the_amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `confirmation_feedback_forms`
--

TRUNCATE TABLE `confirmation_feedback_forms`;
--
-- Dumping data for table `confirmation_feedback_forms`
--

INSERT INTO `confirmation_feedback_forms` (`id`, `user_id`, `manager_id`, `discipline`, `punctuality`, `work_ethics`, `team_work`, `response_towards_feedback`, `elaborate_performance`, `top_3_highlights_1`, `top_3_highlights_2`, `top_3_highlights_3`, `major_task_1`, `major_task_2`, `major_task_3`, `add_value_in_team`, `add_value_in_team_share_instance`, `areas_of_improvement_1`, `areas_of_improvement_2`, `areas_of_improvement_3`, `met_your_expectations`, `met_your_expectations_other_specify`, `are_you_sure_to_confirm`, `recommend_pip_detailed_plan`, `increment_on_confirmation`, `mention_the_amount`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 36, 10, '1', '2', '3', '4', '5', '<p>Kindly elaborate on his/her performance of the last 3 months?</p>', 'Mention top 3 highlights of Shweta Jaiswal 1', 'Mention top 3 highlights of Shweta Jaiswal 2', 'Mention top 3 highlights of Shweta Jaiswal 3', 'Mention the major task that have been accomplished by Shweta Jaiswal?  1', 'Mention the major task that have been accomplished by Shweta Jaiswal?  2', 'Mention the major task that have been accomplished by Shweta Jaiswal?  3', 'Yes', '<p>If Yes, Please share an instance in details.</p>', 'Mention 3 areas of improvement? 1', 'Mention 3 areas of improvement? 2', 'Mention 3 areas of improvement? 3', 'Yes', '<p>Other (please specify)</p>', 'No, Put under PIP', 'If you want to recommend PIP, Pls share a detailed plan.', 'Yes', '10K', '2022-09-07 12:08:53', '0', '2', NULL, '2022-09-12 10:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_generate_emails`
--

DROP TABLE IF EXISTS `confirmation_generate_emails`;
CREATE TABLE `confirmation_generate_emails` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `updated_by_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `letter_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `increment_amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promotion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appraisal_cycle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_date` date DEFAULT NULL,
  `session_time` time DEFAULT NULL,
  `poc_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `confirmation_generate_emails`
--

TRUNCATE TABLE `confirmation_generate_emails`;
--
-- Dumping data for table `confirmation_generate_emails`
--

INSERT INTO `confirmation_generate_emails` (`id`, `user_id`, `updated_by_id`, `member_name`, `letter_type`, `increment_amount`, `promotion`, `appraisal_cycle`, `session_date`, `session_time`, `poc_name`, `location`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 36, 39, 'Shweta Jaiswal', '5', '90000', 'Project Manager', '2023-10-01', '2022-09-12', '10:30:00', '39', 'Gurugram - AIHP', '2022-09-14 09:48:00', '0', '2', NULL, '2022-09-14 09:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_moms`
--

DROP TABLE IF EXISTS `confirmation_moms`;
CREATE TABLE `confirmation_moms` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `manager_id` bigint UNSIGNED NOT NULL,
  `minutes_of_meeting` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hidden_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `confidence` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `communication` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_relevance` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `overall_growth_individual` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `average_rating_entire_presentation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommend_increment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_much_increment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_much_increment_amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `are_you_sure_to_confirm` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `confirmation_moms`
--

TRUNCATE TABLE `confirmation_moms`;
--
-- Dumping data for table `confirmation_moms`
--

INSERT INTO `confirmation_moms` (`id`, `user_id`, `manager_id`, `minutes_of_meeting`, `hidden_notes`, `content`, `confidence`, `communication`, `data_relevance`, `overall_growth_individual`, `average_rating_entire_presentation`, `recommend_increment`, `how_much_increment`, `how_much_increment_amount`, `are_you_sure_to_confirm`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 36, 10, '<p><strong>Minutes of Meeting&nbsp;</strong>Minutes of Meeting Minutes of Meeting Minutes of Meeting</p>\r\n\r\n<ul>\r\n	<li><strong>HR </strong>Minutes of Meeting Minutes</li>\r\n	<li>of MeetingMinutes of MeetingMinutes</li>\r\n	<li>of MeetingMinutes of MeetingMinutes of</li>\r\n</ul>\r\n\r\n<p><strong>Minutes </strong>of Meeting Minutes of Meeting</p>\r\n\r\n<ol>\r\n	<li>Minutes of Meeting</li>\r\n	<li>Minutes of Meeting</li>\r\n	<li>Minutes of Meeting from HR</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>', NULL, '1', '2', '4', '4', '5', '3.2', 'No', NULL, '0', 'Yes, early confirmation', '2022-09-09 11:52:49', '0', '2', NULL, '2022-09-12 07:15:40'),
(2, 36, 39, '<p><strong>Minutes of Meeting&nbsp;</strong>Minutes of Meeting Minutes of Meeting Minutes of Meeting</p>\r\n\r\n<ul>\r\n	<li><strong>HR </strong>Minutes of Meeting Minutes</li>\r\n	<li>of MeetingMinutes of MeetingMinutes</li>\r\n	<li>of MeetingMinutes of MeetingMinutes of</li>\r\n</ul>\r\n\r\n<p><strong>Minutes </strong>of Meeting Minutes of Meeting</p>\r\n\r\n<ol>\r\n	<li>Minutes of Meeting</li>\r\n	<li>Minutes of Meeting</li>\r\n	<li>Minutes of Meeting from HR</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>', '<p><strong>HR </strong>Hidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notesHidden notes</p>', '2', '2', '2', '3', '3', '2.4', 'Yes', '%', '11', 'Defer Confirmation without PIP for 60 Days', '2022-09-12 11:53:53', '0', '2', NULL, '2022-09-12 11:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `days_45_checkin_members`
--

DROP TABLE IF EXISTS `days_45_checkin_members`;
CREATE TABLE `days_45_checkin_members` (
  `id` bigint NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `official_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reporting_manager` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reporting_manager_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `head_of_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `hr_name_taking_session` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_yourself_category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jd` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reliability` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_spirit` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attendance` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attitude` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rules` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peers` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `integrity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `win_win` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `synergize` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closure` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kiss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `innovation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celebration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_work_culture` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processes_policies_well_defined` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enjoy_work_life_balance` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `happy_with_treated_in_company` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title_kras` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `necessary_resources_available` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feel_grow_in_organization` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complete_clarity_my_role` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overall_happy_with_job_role` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_elaborative_well_explained` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_duration_apt` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proper_modules_defined_topic` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adequate_supporting_material` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clarity_on_topics_during_training` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `great_relationship_with_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_properly_feedback_shared_timely` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openly_share_opinions` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receive_adequate_guidance` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receive_adequate_timely_feedback` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_quick_resolution_issue` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequently_receive_feedback_manager` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `any_additional_feedback_manager` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `receive_proper_job_kra` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proper_training_plan` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_executed_planned` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marked_regularly_your_eod` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wpr_happen_atleast_once_week` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `one_to_one_interaction` enum('','NA','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `best_experience_tenure` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `like_most_working` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `like_to_change_add` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `who_inspired_you_organization` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `mention_achievement` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `facing_any_challenges` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `need_additional_training` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `any_additional_feedback_share` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Truncate table before insert `days_45_checkin_members`
--

TRUNCATE TABLE `days_45_checkin_members`;
--
-- Dumping data for table `days_45_checkin_members`
--

INSERT INTO `days_45_checkin_members` (`id`, `user_id`, `member_name`, `member_id`, `designation`, `department`, `official_email`, `company_name`, `location_name`, `reporting_manager`, `reporting_manager_name`, `head_of_department`, `joining_date`, `hr_name_taking_session`, `place_yourself_category`, `target`, `response`, `jd`, `reliability`, `team_spirit`, `attendance`, `attitude`, `rules`, `peers`, `integrity`, `win_win`, `synergize`, `closure`, `knowledge`, `kiss`, `innovation`, `celebration`, `company_work_culture`, `processes_policies_well_defined`, `enjoy_work_life_balance`, `happy_with_treated_in_company`, `job_title_kras`, `necessary_resources_available`, `feel_grow_in_organization`, `complete_clarity_my_role`, `overall_happy_with_job_role`, `training_elaborative_well_explained`, `training_duration_apt`, `proper_modules_defined_topic`, `adequate_supporting_material`, `clarity_on_topics_during_training`, `great_relationship_with_manager`, `reviewed_properly_feedback_shared_timely`, `openly_share_opinions`, `receive_adequate_guidance`, `receive_adequate_timely_feedback`, `get_quick_resolution_issue`, `frequently_receive_feedback_manager`, `any_additional_feedback_manager`, `receive_proper_job_kra`, `proper_training_plan`, `training_executed_planned`, `marked_regularly_your_eod`, `wpr_happen_atleast_once_week`, `one_to_one_interaction`, `best_experience_tenure`, `like_most_working`, `like_to_change_add`, `who_inspired_you_organization`, `mention_achievement`, `facing_any_challenges`, `need_additional_training`, `any_additional_feedback_share`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(2, 11, 'Athif Hussain', 'BVC2085', '10', '3', 'athif.hussain@bvceservices.com', '1', '1', 'Sarbari Dey', 'Sarbari Dey', '41', '2021-10-26', '39', '2', '1', '2', '3', '4', '5', 'NA', '5', '4', '3', '+/+', '+/+', '+/+', '+/-', '+/-', '+/-', '-/-', '-/-', '1', '2', '3', '4', '5', 'NA', '5', '4', '3', '2', '1', '2', '3', '4', '5', 'NA', '5', '4', '3', '2', 'How frequently do you want to receive feedback from your manager about your performance?', '<p>Any additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari DeyAny additional feedback for&nbsp;Sarbari Dey</p>', 'Yes', 'No', 'NA', 'No', 'Yes', 'No', '<p>What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?What&rsquo;s the best experience you have had during your tenure till date?</p>', '<p>What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?What do you like the most working here?</p>', '<p>What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?What would you like to change/add in the organization?</p>', '<p>What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?What/Who has inspired you in this organization, based on your experiences so far?</p>', '<p>Mention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till dateMention your achievement(s) in terms of your work till date</p>', '<p>Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?Any challenges that you are facing right now?</p>', '<p>Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;Do you need any additional training or support?&nbsp;</p>', '<p>Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;Any additional feedback that you wish to share?&nbsp;</p>', '2022-09-09 11:24:53', '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` bigint UNSIGNED DEFAULT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `departments`
--

TRUNCATE TABLE `departments`;
--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `company_id`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'iGaming', 2, '0', '1', NULL, '2022-09-05 11:16:36'),
(2, 'Publishers\r\n', NULL, '0', '1', NULL, NULL),
(3, 'Tech Operations', NULL, '0', '1', NULL, NULL),
(4, 'Finance & Accounts', NULL, '0', '1', NULL, NULL),
(5, 'HR', NULL, '0', '1', NULL, NULL),
(6, 'Mobile', NULL, '0', '1', NULL, NULL),
(7, 'Pocket Money', NULL, '0', '1', NULL, NULL),
(8, 'Media Buying', NULL, '0', '1', NULL, NULL),
(9, 'Admin Operations', 2, '0', '1', NULL, '2022-09-05 11:16:29'),
(10, 'Education', NULL, '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `designations`
--

DROP TABLE IF EXISTS `designations`;
CREATE TABLE `designations` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` bigint UNSIGNED DEFAULT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `designations`
--

TRUNCATE TABLE `designations`;
--
-- Dumping data for table `designations`
--

INSERT INTO `designations` (`id`, `name`, `company_id`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Associate', NULL, '0', '1', NULL, NULL),
(2, 'Associate Manager', NULL, '0', '1', NULL, NULL),
(3, 'QA (Quality Analyst)', NULL, '0', '1', NULL, NULL),
(4, 'Senior Executive', NULL, '0', '1', NULL, NULL),
(5, 'Senior Associate', NULL, '0', '1', NULL, NULL),
(6, 'Head', NULL, '0', '1', NULL, NULL),
(7, 'Account Manager', 2, '0', '1', NULL, '2022-09-05 11:37:55'),
(8, 'Manager', NULL, '0', '1', NULL, NULL),
(9, 'Senior PHP Developer', NULL, '0', '1', NULL, NULL),
(10, 'PHP Developer', 1, '0', '1', NULL, '2022-09-05 11:38:02'),
(11, 'Executive', NULL, '0', '1', NULL, NULL),
(12, 'Senior System Engineer', NULL, '0', '1', NULL, NULL),
(13, 'Shopify (UI) Developer', NULL, '0', '1', NULL, NULL),
(14, 'Project Co-Ordinator', NULL, '0', '1', NULL, NULL),
(15, 'HR-Head', 1, '0', '1', NULL, NULL),
(16, 'Business Manager', 2, '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `failed_jobs`
--

TRUNCATE TABLE `failed_jobs`;
-- --------------------------------------------------------

--
-- Table structure for table `fresh_eye_journals`
--

DROP TABLE IF EXISTS `fresh_eye_journals`;
CREATE TABLE `fresh_eye_journals` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name_ajax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name_fresh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenure_in_month` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reporting_manager_name_ajax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reporting_manager_fresh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `head_of_department_name_ajax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `head_of_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `your_journey_so_far_in_company` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `top_3_things_like_your_job_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_things_like_your_job_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_things_like_your_job_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_things_wish_change_job_role_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_things_wish_change_job_role_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_things_wish_change_job_role_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `satisfaction_job_role` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `well_equipped_perform_job` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `able_maintain_work_life_balance` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feel_respected_my_peers` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestions_heard_implemented` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_good_bond_superiors` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `know_what_i_expected_to_do` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `i_feel_grow_in_organization` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `any_exemplary_work_achievement_showcase` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `any_additional_trainings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `what_do_you_like_about_company` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `what_do_you_dislike_about_company` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `satisfied_employee_benefits_offered_company` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `work_culture` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recruitment_process` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `induction_process` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `on_job_training_process` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clear_communication_changes_policy` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feeling_belongingness_organization` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `having_best_friend_at_work` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_life_balance` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `any_detailed_feedback_support_your_response` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quickness_in_respond_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_well_received_guidance_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_clearly_your_goals_set_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_transparent_is_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wprs_happen_every_week_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_well_adjust_changing_priorities_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_comfortable_feel_sharing_feedback_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_well_able_learn_under_guidance_reporting_manager` enum('','NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `our_organization_believes_mantra` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quickness_in_respond_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_well_received_guidance_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_clearly_your_goals_set_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_transparent_is_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `frequent_1_1_happen_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_well_adjust_changing_priorities_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_comfortable_feel_sharing_feedback_reporting_manager_qi` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `top_3_strengths_reporting_manager_qi_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_strengths_reporting_manager_qi_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_strengths_reporting_manager_qi_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_reporting_manager_qi_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_reporting_manager_qi_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_reporting_manager_qi_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `our_organization_believes_mantra_reporting_manager_qi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quickness_in_respond_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_well_received_guidance_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_clearly_your_goals_set_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_transparent_is_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `frequent_1_1_happen_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_well_adjust_changing_priorities_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `how_comfortable_feel_sharing_feedback_hod_qj` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `top_3_strengths_hod_qj_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_strengths_hod_qj_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_3_strengths_hod_qj_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_hod_qj_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_hod_qj_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `three_areas_improvement_hod_qj_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `our_organization_believes_mantra_hod_qj` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `admin_operations` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `advertiser_sales` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `advertisers` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `finance_accounts` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `human_resources` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `management` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `network_operations` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pocket_money` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `publishers` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tech_operations_development` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `support_ea_pa` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `education` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `igaming` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tech_operations_shopify` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tech_operations_creative` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mobile` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vcommission_uk` enum('','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `any_additional_feedback_any_department` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `any_issue_concern_management` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `fresh_eye_journals`
--

TRUNCATE TABLE `fresh_eye_journals`;
--
-- Dumping data for table `fresh_eye_journals`
--

INSERT INTO `fresh_eye_journals` (`id`, `user_id`, `member_name`, `member_id`, `designation`, `department`, `company_name_ajax`, `company_name_fresh`, `location_name`, `tenure_in_month`, `reporting_manager_name_ajax`, `reporting_manager_fresh`, `head_of_department_name_ajax`, `head_of_department`, `your_journey_so_far_in_company`, `top_3_things_like_your_job_1`, `top_3_things_like_your_job_2`, `top_3_things_like_your_job_3`, `three_things_wish_change_job_role_1`, `three_things_wish_change_job_role_2`, `three_things_wish_change_job_role_3`, `satisfaction_job_role`, `well_equipped_perform_job`, `able_maintain_work_life_balance`, `feel_respected_my_peers`, `suggestions_heard_implemented`, `share_good_bond_superiors`, `know_what_i_expected_to_do`, `i_feel_grow_in_organization`, `any_exemplary_work_achievement_showcase`, `any_additional_trainings`, `what_do_you_like_about_company`, `what_do_you_dislike_about_company`, `satisfied_employee_benefits_offered_company`, `work_culture`, `recruitment_process`, `induction_process`, `on_job_training_process`, `clear_communication_changes_policy`, `feeling_belongingness_organization`, `having_best_friend_at_work`, `work_life_balance`, `any_detailed_feedback_support_your_response`, `quickness_in_respond_reporting_manager`, `how_well_received_guidance_reporting_manager`, `how_clearly_your_goals_set_reporting_manager`, `how_transparent_is_reporting_manager`, `wprs_happen_every_week_reporting_manager`, `how_well_adjust_changing_priorities_reporting_manager`, `how_comfortable_feel_sharing_feedback_reporting_manager`, `how_well_able_learn_under_guidance_reporting_manager`, `our_organization_believes_mantra`, `quickness_in_respond_reporting_manager_qi`, `how_well_received_guidance_reporting_manager_qi`, `how_clearly_your_goals_set_reporting_manager_qi`, `how_transparent_is_reporting_manager_qi`, `frequent_1_1_happen_reporting_manager_qi`, `how_well_adjust_changing_priorities_reporting_manager_qi`, `how_comfortable_feel_sharing_feedback_reporting_manager_qi`, `top_3_strengths_reporting_manager_qi_1`, `top_3_strengths_reporting_manager_qi_2`, `top_3_strengths_reporting_manager_qi_3`, `three_areas_improvement_reporting_manager_qi_1`, `three_areas_improvement_reporting_manager_qi_2`, `three_areas_improvement_reporting_manager_qi_3`, `our_organization_believes_mantra_reporting_manager_qi`, `quickness_in_respond_hod_qj`, `how_well_received_guidance_hod_qj`, `how_clearly_your_goals_set_hod_qj`, `how_transparent_is_hod_qj`, `frequent_1_1_happen_hod_qj`, `how_well_adjust_changing_priorities_hod_qj`, `how_comfortable_feel_sharing_feedback_hod_qj`, `top_3_strengths_hod_qj_1`, `top_3_strengths_hod_qj_2`, `top_3_strengths_hod_qj_3`, `three_areas_improvement_hod_qj_1`, `three_areas_improvement_hod_qj_2`, `three_areas_improvement_hod_qj_3`, `our_organization_believes_mantra_hod_qj`, `admin_operations`, `advertiser_sales`, `advertisers`, `finance_accounts`, `human_resources`, `management`, `network_operations`, `pocket_money`, `publishers`, `tech_operations_development`, `support_ea_pa`, `education`, `igaming`, `tech_operations_shopify`, `tech_operations_creative`, `mobile`, `vcommission_uk`, `any_additional_feedback_any_department`, `any_issue_concern_management`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 11, 'Athif Hussain', 'BVC2085', '10', '3', 'BVC eServices Pvt Ltd', '1', '1', '10', 'Sarbari Dey', 'Sarbari Dey', 'Test1 User', '41', '<p>How has your journey been so far in&nbsp;BVC eServices Pvt Ltd? Explain in detailHow has your journey been so far in&nbsp;BVC eServices Pvt Ltd? Explain in detailHow has your journey been so far in&nbsp;BVC eServices Pvt Ltd? Explain in detailHow has your journey been so far in&nbsp;BVC eServices Pvt Ltd? Explain in detailHow has your journey been so far in&nbsp;BVC eServices Pvt Ltd? Explain in detail</p>', 'Top 1 things that you like about your job role.', 'Top 2 things that you like about your job role.', 'Top 3 things that you like about your job role.', '1 Three things that you wish to change in your job role. *', '2 Three things that you wish to change in your job role. *', '3 Three things that you wish to change in your job role. *', '1', '2', '3', '4', '5', '4', '5', '2', '<p>ny exemplary work or achievement that you would like to showcaseny exemplary work or achievement that you would like to showcaseny exemplary work or achievement that you would like to showcaseny exemplary work or achievement that you would like to showcaseny exemplary work or achievement that you would like to showcaseny exemplary work or achievement that you would like to showcase</p>', '<p>Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?Any additional trainings that you&#39;d like?</p>', '<p>What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?What do you like about&nbsp;BVC eServices Pvt Ltd?</p>', '<p>What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?What do you dislike about&nbsp;BVC eServices Pvt Ltd?</p>', '<p>How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;How satisfied are you with employee benefits being offered by&nbsp;BVC eServices Pvt Ltd? Please elaborate.&nbsp;</p>', '1', '2', '3', '4', '5', '4', '3', '2', '<p>Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?Any detailed feedback you would like to share to support your response on the above parameters?</p>', '1', '2', '3', '4', '5', '4', '3', '2', '<p>Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;</p>', '1', '2', '3', '4', '5', '4', '3', '1 Share top three strengths of Reporting Manager (Sarbari Dey)', '2 Share top three strengths of Reporting Manager (Sarbari Dey)', '3 Share top three strengths of Reporting Manager (Sarbari Dey)', '1 Share three areas of improvement for Reporting Manager (Sarbari Dey).', '2 Share three areas of improvement for Reporting Manager (Sarbari Dey).', '3 Share three areas of improvement for Reporting Manager (Sarbari Dey).', '<p>Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.</p>', '1', '2', '3', '4', '5', '4', '3', 'Share top three strengths HOD(Test1 User). 1', 'Share top three strengths HOD(Test1 User). 2', 'Share top three strengths HOD(Test1 User). 3', 'Share three areas of improvement HOD(Test1 User). * 1', 'Share three areas of improvement HOD(Test1 User). * 2', 'Share three areas of improvement HOD(Test1 User). * 3', '<p>Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;Our organization believes in the mantra of &#39;Lead by Example&#39;. Do you feel motivated by actions/way of work? Explain in detail.&nbsp;</p>', '1', '2', '3', '4', '5', '4', '', '', '', '', '', '', '', '', '', '', '', '<p>Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?Any additional feedback for any department that you would like to share?</p>', '<p>Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?Any issue or concern that you would like to talk to management about?</p>', '2022-09-09 11:40:15', '0', '1', NULL, '2022-09-12 07:12:44');

-- --------------------------------------------------------

--
-- Table structure for table `hiring_surveys`
--

DROP TABLE IF EXISTS `hiring_surveys`;
CREATE TABLE `hiring_surveys` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recruiter_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_name_position_open` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation_name_open_position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_openings` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `all_posoitions_closed` enum('','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recruiter_helpful_recruitment_process` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `recruiter_response` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `recruiter_understanding_job_requirement` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `quality_of_candidates_presented` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `number_of_candidates_presented` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `rate_the_recruiter_correct_information` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `assessment_screening_candidates` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `time_taken_fill_open_position` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `overall_satisfied_hiring_recruiting_process` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `additional_feedback_recruiter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `any_suggestions_improve_hiring_process` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `hiring_surveys`
--

TRUNCATE TABLE `hiring_surveys`;
--
-- Dumping data for table `hiring_surveys`
--

INSERT INTO `hiring_surveys` (`id`, `user_id`, `member_name`, `designation`, `department`, `location`, `company_name`, `recruiter_name`, `location_name_position_open`, `designation_name_open_position`, `no_of_openings`, `all_posoitions_closed`, `recruiter_helpful_recruitment_process`, `recruiter_response`, `recruiter_understanding_job_requirement`, `quality_of_candidates_presented`, `number_of_candidates_presented`, `rate_the_recruiter_correct_information`, `assessment_screening_candidates`, `time_taken_fill_open_position`, `overall_satisfied_hiring_recruiting_process`, `additional_feedback_recruiter`, `any_suggestions_improve_hiring_process`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 11, 'Athif Hussain', '10', '3', '1', '1', '40', '1', '10', '2', 'No', '1', '2', '3', '4', '5', '4', '3', '5', '1', '<p><strong>Any additional feedback </strong>you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?Any additional feedback you would like to give for the recruiter?</p>', '<p>Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?Any suggestions you would like to give that would help us to improve the hiring process?</p>', '2022-09-09 10:58:49', '0', '2', NULL, '2022-09-12 06:57:21');

-- --------------------------------------------------------

--
-- Table structure for table `job_opening_types`
--

DROP TABLE IF EXISTS `job_opening_types`;
CREATE TABLE `job_opening_types` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `job_opening_types`
--

TRUNCATE TABLE `job_opening_types`;
--
-- Dumping data for table `job_opening_types`
--

INSERT INTO `job_opening_types` (`id`, `name`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Internal Employee Reference', '0', '1', '2022-08-05 05:12:01', '2022-08-05 05:12:01'),
(2, 'Paid Job Portal', '0', '1', '2022-08-05 05:12:01', '2022-08-05 05:12:01'),
(3, 'Unpaid Job Portal', '0', '1', '2022-08-05 05:12:18', '2022-08-05 05:12:18'),
(4, 'Campus/Institutes', '0', '1', '2022-08-05 05:12:18', '2022-08-17 11:15:41'),
(5, 'Talent Partners', '0', '1', '2022-08-05 05:12:45', '2022-08-05 05:12:45'),
(6, 'Friends/Family/Ex-employee', '0', '1', '2022-08-05 05:12:45', '2022-08-05 05:12:45'),
(7, 'Management Hiring', '0', '1', '2022-08-05 05:13:05', '2022-08-05 05:13:05'),
(8, 'Head-Hunting', '0', '1', '2022-08-05 05:13:05', '2022-08-05 05:13:05'),
(9, 'Walk-In', '0', '1', '2022-08-05 05:13:59', '2022-08-05 05:13:59'),
(10, 'Career Page', '0', '1', '2022-08-05 05:13:59', '2022-08-05 05:13:59'),
(11, 'Paid Ads', '0', '1', '2022-08-05 05:13:59', '2022-08-05 05:13:59'),
(12, 'Social Media', '0', '1', '2022-08-05 05:13:59', '2022-08-05 05:13:59');

-- --------------------------------------------------------

--
-- Table structure for table `letter_types`
--

DROP TABLE IF EXISTS `letter_types`;
CREATE TABLE `letter_types` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `letter_types`
--

TRUNCATE TABLE `letter_types`;
--
-- Dumping data for table `letter_types`
--

INSERT INTO `letter_types` (`id`, `name`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Confirmation Letter', '0', '1', NULL, NULL),
(2, 'Confirmation Letter with Increment', '0', '1', NULL, NULL),
(3, 'Confirmation Letter with Promotion', '0', '1', NULL, NULL),
(4, 'Confirmation Delayed Letter', '0', '1', NULL, NULL),
(5, 'Confirmation Letter with Increment and Promotion', '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `migrations`
--

TRUNCATE TABLE `migrations`;
--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_08_04_050006_add_multiple_column_to_users', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `password_resets`
--

TRUNCATE TABLE `password_resets`;
--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('yfriesen@example.net', '$2y$10$lima4igP1z.Dy9eYhp3FO.w.vrWaOEIGT.30dgQ8KTjHEpa3bP5dq', '2022-08-02 03:15:37'),
('athif.hussain@bvceservices.com', '$2y$10$GnlNHqdJwS5zXHVMwx.xcu6dqqSmvbwNNo2Dtx050wuKLiqpSQjaq', '2022-08-02 06:17:13');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `personal_access_tokens`
--

TRUNCATE TABLE `personal_access_tokens`;
-- --------------------------------------------------------

--
-- Table structure for table `place_yourself_categories`
--

DROP TABLE IF EXISTS `place_yourself_categories`;
CREATE TABLE `place_yourself_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `place_yourself_categories`
--

TRUNCATE TABLE `place_yourself_categories`;
--
-- Dumping data for table `place_yourself_categories`
--

INSERT INTO `place_yourself_categories` (`id`, `name`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Asset to the company', '0', '1', NULL, NULL),
(2, 'Little more to go', '0', '1', NULL, NULL),
(3, 'Long way to go', '0', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `roles`
--

TRUNCATE TABLE `roles`;
--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Employee', '0', '1', NULL, '2022-08-09 12:09:00'),
(2, 'Mentor', '0', '1', NULL, NULL),
(3, 'Manager', '0', '1', NULL, NULL),
(4, 'Head', '0', '1', NULL, '2022-08-09 12:09:02'),
(5, 'HR', '0', '1', NULL, NULL),
(6, 'HR Head', '0', '1', NULL, '2022-08-09 12:14:16'),
(7, 'Management', '0', '1', NULL, '2022-08-09 12:14:18');

-- --------------------------------------------------------

--
-- Table structure for table `training_surveys`
--

DROP TABLE IF EXISTS `training_surveys`;
CREATE TABLE `training_surveys` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `trainer_1_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trainer_1_id` bigint UNSIGNED DEFAULT NULL,
  `expertise_on_subject_matter_1` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clear_effective_communication_skills_1` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `effective_delivery_content_1` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `timely_response_queries_1` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `comfortability_sharing_concerns_doubts_1` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `additional_feedback_trainer_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `trainer_2_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trainer_2_id` bigint UNSIGNED DEFAULT NULL,
  `expertise_on_subject_matter_2` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clear_effective_communication_skills_2` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `effective_delivery_content_2` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `timely_response_queries_2` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `comfortability_sharing_concerns_doubts_2` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `additional_feedback_trainer_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `trainer_3_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trainer_3_id` bigint UNSIGNED DEFAULT NULL,
  `expertise_on_subject_matter_3` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clear_effective_communication_skills_3` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `effective_delivery_content_3` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `timely_response_queries_3` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `comfortability_sharing_concerns_doubts_3` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `additional_feedback_trainer_3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `trainer_4_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trainer_4_id` bigint UNSIGNED DEFAULT NULL,
  `expertise_on_subject_matter_4` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clear_effective_communication_skills_4` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `effective_delivery_content_4` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `timely_response_queries_4` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `comfortability_sharing_concerns_doubts_4` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `additional_feedback_trainer_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `trainer_5_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trainer_5_id` bigint UNSIGNED DEFAULT NULL,
  `expertise_on_subject_matter_5` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clear_effective_communication_skills_5` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `effective_delivery_content_5` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `timely_response_queries_5` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `comfortability_sharing_concerns_doubts_5` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `additional_feedback_trainer_5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `training_first_week_joining` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `training_sessions_went_as_planned` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `training_topics_were_covered_in_detail` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `training_was_effective_helping` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `clearly_understood_all_modules` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `self_study_material_useful` enum('NA','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `is_there_any_topic` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `interesting_part_elaborate` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `any_suggestions_feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `training_surveys`
--

TRUNCATE TABLE `training_surveys`;
--
-- Dumping data for table `training_surveys`
--

INSERT INTO `training_surveys` (`id`, `user_id`, `member_name`, `member_id`, `designation`, `department`, `email`, `company_name`, `location_name`, `trainer_1_name`, `trainer_1_id`, `expertise_on_subject_matter_1`, `clear_effective_communication_skills_1`, `effective_delivery_content_1`, `timely_response_queries_1`, `comfortability_sharing_concerns_doubts_1`, `additional_feedback_trainer_1`, `trainer_2_name`, `trainer_2_id`, `expertise_on_subject_matter_2`, `clear_effective_communication_skills_2`, `effective_delivery_content_2`, `timely_response_queries_2`, `comfortability_sharing_concerns_doubts_2`, `additional_feedback_trainer_2`, `trainer_3_name`, `trainer_3_id`, `expertise_on_subject_matter_3`, `clear_effective_communication_skills_3`, `effective_delivery_content_3`, `timely_response_queries_3`, `comfortability_sharing_concerns_doubts_3`, `additional_feedback_trainer_3`, `trainer_4_name`, `trainer_4_id`, `expertise_on_subject_matter_4`, `clear_effective_communication_skills_4`, `effective_delivery_content_4`, `timely_response_queries_4`, `comfortability_sharing_concerns_doubts_4`, `additional_feedback_trainer_4`, `trainer_5_name`, `trainer_5_id`, `expertise_on_subject_matter_5`, `clear_effective_communication_skills_5`, `effective_delivery_content_5`, `timely_response_queries_5`, `comfortability_sharing_concerns_doubts_5`, `additional_feedback_trainer_5`, `training_first_week_joining`, `training_sessions_went_as_planned`, `training_topics_were_covered_in_detail`, `training_was_effective_helping`, `clearly_understood_all_modules`, `self_study_material_useful`, `is_there_any_topic`, `interesting_part_elaborate`, `any_suggestions_feedback`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 11, 'Athif Hussain', 'BVC2085', '10', '3', 'athif.hussain@bvceservices.com', '1', '1', 'Sandra Vasisht', 39, '1', '2', '3', '4', '5', '<p>Any additional comments for <strong>Sandra Vasisht</strong>Any additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra VasishtAny additional comments for Sandra Vasisht</p>', 'Test1 User', 41, '1', '2', '3', '4', '5', '<p>Any additional comments for <strong>Test1 UserAny </strong>additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 UserAny additional comments for Test1 User</p>', NULL, NULL, '', '', '', '', '', '', NULL, NULL, '', '', '', '', '', '', NULL, NULL, '', '', '', '', '', '', '1', '2', '3', '4', '5', 'NA', '<p>Is there any topic that you still need training on?Is there any topic that you still need training on?Is there any topic that you still need training on?Is there any topic that you still need training on?Is there any topic that you still need training on?Is there any topic that you still need training on?Is there any topic that you still need training on?</p>', '<p>Which part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborateWhich part of the training was the most interesting? Please elaborate</p>', '<p>Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?Any suggestion/feedback you would like to give in helping us to improve our training sessions?</p>', '2022-09-09 11:00:42', '0', '2', NULL, '2022-09-12 09:54:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `manager_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `manager_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `member_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint UNSIGNED DEFAULT NULL,
  `company_id` bigint UNSIGNED DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_location_id` bigint UNSIGNED DEFAULT NULL,
  `reporting_to_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_type` enum('Probation','Confirmed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Probation',
  `date_of_confirmation` date DEFAULT NULL,
  `due_date_of_confirmation` date DEFAULT NULL,
  `appraisal_cycle` date DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_ppt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_commitment_details` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `joining_date`, `manager_name`, `manager_email`, `status`, `is_deleted`, `member_id`, `designation`, `department`, `role_id`, `company_id`, `last_name`, `company_location_id`, `reporting_to_id`, `employee_type`, `date_of_confirmation`, `due_date_of_confirmation`, `appraisal_cycle`, `gender`, `confirmation_ppt`, `profile_image`, `confirmation_commitment_details`) VALUES
(10, 'Sarbari', 'sarbari.dey@bvceservices.com', '2022-08-02 01:50:05', '$2y$10$CR.FyFTNmlBV41fMuNyPnus2LTt2zuRxFdpL5Oe7QE0mbzBrad4ya', 'KIXlRbDfTzLbSvAWV7kse4ASRoaGC8crtV6UA8N7LWCvaN5bvXOq04nsMTeZ', '2022-08-02 01:50:06', '2022-08-02 01:50:06', '2022-06-25', 'Sarbari Dey', '', '0', '0', 'BVC2048', NULL, NULL, 3, 1, 'Dey', 1, 'BVC2048', 'Confirmed', NULL, NULL, NULL, 'Female', NULL, NULL, NULL),
(11, 'Athif', 'athif.hussain@bvceservices.com', NULL, '$2y$10$CR.FyFTNmlBV41fMuNyPnus2LTt2zuRxFdpL5Oe7QE0mbzBrad4ya', 'n7hHf1AydWNmDEAEGV3wjNev0kQBKFAGxLOXqsB7efXRv6CeJWjyCvatL4KB', '2022-08-02 03:31:15', '2022-09-12 07:02:26', '2021-10-26', 'Sarbari Dey', 'sarbari.dey@bvceservices.com', '1', '0', 'BVC2085', '10', '3', 1, 1, 'Hussain', 1, 'BVC2048', 'Confirmed', '2022-02-01', NULL, NULL, 'Male', '/storage/app/all-ppt/54e2NgkpDO8Cx3JGDtT4sSspDjRJeAsEdK1yFWpq.pptx', '/storage/app/all-profile-images/wJPOJcktBsBPqGwSEQNGClh0JS3hq8sS3XY6NWe1.jpg', NULL),
(13, 'Lakshay', 'lakshay.sharma@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-08-16', 'Viren Anand', '', '1', '0', '1528', '1', '1', 1, 2, 'Sharma', 1, '1441', 'Probation', NULL, '2022-12-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(14, 'Arpit', 'arpit.srivastava@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-08-16', 'Viren Anand', '', '1', '0', '1527', '2', '2', 1, 2, 'Srivastava', 1, '1441', 'Probation', NULL, '2022-12-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(15, 'Vishal', 'vishal.raj@bvceservices.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-08-02', 'Pankaj Kumar Gupta', '', '1', '0', 'BVC2138', '3', '3', 1, 1, 'Raj', 1, 'BVC2101', 'Probation', NULL, '2022-11-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(16, 'Vijay Kumar', 'vijay.kumar@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-08-02', 'Sunava Datta', '', '1', '0', '1526', '4', '4', 1, 2, 'Thakur', 1, 'BVC2092', 'Probation', NULL, '2022-11-01', NULL, 'Male', NULL, NULL, NULL),
(17, 'Tarmeet', 'tarmeet.kaur@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-08-02', 'Sandra Bysack', '', '1', '0', '1525', '2', '5', 1, 2, 'Kaur', 1, '1125', 'Probation', NULL, '2022-11-01', NULL, 'Female', NULL, NULL, NULL),
(18, 'Rinika', 'rinika.khattar2@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-27', 'Srinand Sridharan', '', '1', '0', '1524', '2', '6', 1, 2, 'Khattar', 1, '1479', 'Probation', NULL, NULL, '2023-10-01', 'Female', NULL, NULL, NULL),
(19, 'Rohit', 'rohit.gupta@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-21', 'Ashish Giri', '', '1', '0', '1523', '5', '1', 1, 2, 'Gupta', 1, '1462', 'Probation', NULL, NULL, '2023-10-01', 'Male', NULL, NULL, NULL),
(20, 'Sorav', 'sorav.kumar@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-20', 'Ashish Giri', '', '1', '0', '1522', '1', '1', 1, 2, 'Kumar', 1, '1462', 'Probation', NULL, NULL, '2023-10-01', 'Male', NULL, NULL, NULL),
(21, 'Bintu', 'bintu.garg@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-19', 'Sunava Datta', '', '1', '0', '1521', '6', '4', 1, 2, 'Garg', 1, 'BVC2092', 'Probation', NULL, NULL, '2023-10-01', 'Male', NULL, NULL, NULL),
(22, 'Garima', 'garima.arya@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-05', 'VV Satyanarayana', '', '1', '0', '1519', '7', '7', 1, 2, 'Arya', 1, '1219', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Female', NULL, NULL, NULL),
(23, 'Unnati', 'unnati.sobti@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-07-01', 'Yashvinder Singh Thakur', '', '1', '0', '1518', '8', '2', 1, 2, 'Sobti', 2, '1206', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Female', NULL, NULL, NULL),
(24, 'Gaurav', 'gaurav.kumar2@bvceservices.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-21', 'Pankaj Kumar Gupta', '', '1', '0', 'BVC2136', '9', '3', 1, 1, 'Kumar', 1, 'BVC2101', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(25, 'Sheetal', 'sheetal.sandewal@adwaysvc.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-21', 'Pawan Wankhede', '', '1', '0', '7002', '8', '8', 1, 3, 'Sandewal', 1, '7001', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(26, 'Amit Kumar', 'amit.kumar@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-21', 'Sunava Datta', '', '1', '0', '1517', '11', '4', 1, 2, 'Chaudhery', 1, 'BVC2092', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(27, 'Rachna', 'rachna.mishra@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-21', 'Srinand Sridharan', '', '1', '0', '1516', '1', '6', 1, 2, 'Mishra', 1, '1479', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Female', NULL, NULL, NULL),
(28, 'Karan', 'karan.sharma@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-16', 'Puneet Rohaj', '', '1', '0', '1515', '7', '2', 1, 2, 'Sharma', 2, '1210', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(29, 'Divya', 'divya.singh@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-16', 'Puneet Rohaj', '', '1', '0', '1514', '7', '2', 1, 2, 'Singh', 2, '1210', 'Probation', NULL, '2022-10-01', '2023-10-01', 'Female', NULL, NULL, NULL),
(30, 'Rohit', 'rohit.kumar@bvceservices.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-01', 'Harinder Singh', '', '1', '0', 'BVC2126', '12', '9', 1, 1, 'Kumar', 1, '1171', 'Probation', NULL, '2022-09-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(31, 'Rajender', 'rajender.singh@bvceservices.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-01', 'Pankaj Kumar Gupta', '', '1', '0', 'BVC2124', '13', '3', 1, 1, 'Singh', 1, 'BVC2101', 'Probation', NULL, '2022-09-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(32, 'Prateek', 'prateek.kumar@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-01', 'Ashish Giri', '', '1', '0', '1509', '7', '1', 1, 2, 'Kumar', 1, '1462', 'Probation', NULL, '2022-09-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(33, 'Anand', 'anand.sharma@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-01', 'Viren Anand', '', '1', '0', '1506', '7', '2', 1, 2, 'Sharma', 1, '1441', 'Probation', NULL, '2022-09-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(34, 'Tuhin', 'tuhin.lahiri@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-06-01', 'Viren Anand', '', '1', '0', '1505', '7', '2', 1, 2, 'Lahiri', 1, '1441', 'Probation', NULL, '2022-09-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(35, 'Amit Kumar', 'amit.yadav1@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-05-04', 'Hardik Gupta', '', '1', '0', '1502', '1', '10', 1, 2, 'Yadav', 1, '1454', 'Probation', NULL, '2022-08-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(36, 'Shweta', 'shweta.jaiswal@bvceservices.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-05-04', 'Sarbari Dey', 'sarbari.dey@bvceservices.com', '1', '0', 'BVC2120', '14', '3', 1, 1, 'Jaiswal', 1, 'BVC2048', 'Probation', NULL, '2022-08-01', '2023-10-01', 'Female', NULL, '/storage/app/all-profile-images/RYF8lQyJpXKOXAhQvrlyM2H0Y2PY9u3WILeNgq5x.png', NULL),
(37, 'Sunny Kumar', 'sunny.yadav@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-05-04', 'Sunava Datta', '', '1', '0', '1500', '11', '4', 1, 2, 'Yadav', 1, 'BVC2092', 'Probation', NULL, '2022-08-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(38, 'Suraj', 'suraj.kumar@vcommission.com', '2017-08-22 09:01:00', '', '', '2017-08-22 09:01:00', '2017-08-22 09:01:00', '2022-04-26', 'Sunava Datta', '', '1', '0', '1498', '4', '4', 1, 2, 'Kumar', 1, 'BVC2092', 'Probation', NULL, '2022-08-01', '2023-10-01', 'Male', NULL, NULL, NULL),
(39, 'Sandra', 'sandra.vasisht@vcommission.com', NULL, '$2y$10$CR.FyFTNmlBV41fMuNyPnus2LTt2zuRxFdpL5Oe7QE0mbzBrad4ya', NULL, NULL, '2022-08-19 04:24:28', '2018-08-01', 'Parul Bhargava', 'parul.bhargava@vcommission.com', '1', '0', '1125', '15', '5', 6, 2, 'Vasisht', 1, '1002', 'Confirmed', NULL, NULL, '2022-10-01', 'Female', '', NULL, NULL),
(40, 'Vikas', 'vikas.kumar@vcommission.com', NULL, '$2y$10$CR.FyFTNmlBV41fMuNyPnus2LTt2zuRxFdpL5Oe7QE0mbzBrad4ya', NULL, NULL, '2022-08-18 12:06:19', NULL, 'Tarang Bhargava', 'tarang.bhargava@vcommission.com', '1', '0', '1123', '6', '9', 7, 2, 'Kumar', 1, '1001', 'Confirmed', NULL, NULL, NULL, 'Male', '/storage/app/', NULL, NULL),
(41, 'Test1', 'test@gmail.com', NULL, '', NULL, '2022-09-09 16:18:36', '2022-09-09 16:18:36', NULL, 'Sarbari Dey', '', '1', '0', '1000', '6', '3', 4, 2, 'User', 1, '1001', 'Confirmed', NULL, NULL, NULL, 'Male', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_interview_forms`
--

DROP TABLE IF EXISTS `user_interview_forms`;
CREATE TABLE `user_interview_forms` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `member_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `official_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_position_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `learn_about_job_opening` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_source_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_hr_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approachable` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `respectful` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `explain_job_role` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `explain_company_background` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `shared_proper_interview_information` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `discussed_my_profile` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `shared_interview_feedback_quickly` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `additional_feedback_recruiter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rate_overall_conduct` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `professionalism` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `friendliness` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `heplful` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `approachable_interviewers` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `respectable` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `knowledgeable` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `clear_communication_about_company` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `clear_communication_job_role` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `process_started_on_time` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `process_fair_apt` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `seating_arrangement_comfortable` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `staff_helpful_supportive` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `received_interview_feedback` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `define_overall_interview_process` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_overall_interview_process` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `comments_suggestions_feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '0 for unsaved, 1 for draft,2 for publish',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `user_interview_forms`
--

TRUNCATE TABLE `user_interview_forms`;
--
-- Dumping data for table `user_interview_forms`
--

INSERT INTO `user_interview_forms` (`id`, `user_id`, `member_name`, `official_email`, `company_name`, `job_position_name`, `location_name`, `learn_about_job_opening`, `referral_source_name`, `company_hr_name`, `approachable`, `respectful`, `explain_job_role`, `explain_company_background`, `shared_proper_interview_information`, `discussed_my_profile`, `shared_interview_feedback_quickly`, `additional_feedback_recruiter`, `rate_overall_conduct`, `professionalism`, `friendliness`, `heplful`, `approachable_interviewers`, `respectable`, `knowledgeable`, `clear_communication_about_company`, `clear_communication_job_role`, `process_started_on_time`, `process_fair_apt`, `seating_arrangement_comfortable`, `staff_helpful_supportive`, `received_interview_feedback`, `define_overall_interview_process`, `rate_overall_interview_process`, `comments_suggestions_feedback`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 11, 'Athif Hussain', 'athif.hussain@bvceservices.com', '1', '10', '1', '10', 'Dheeraj Yadav', 'Supriya and Pooja', '2', '2', '3', '2', '5', '4', '3', '<p>Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?Any additional feedback for the recruiter?</p>', '1', '2', '3', '4', '5', '4', '3', '2', '1', '2', '3', '4', '5', '4', 'Time consuming', '3', '<p>If you <strong>have any comments, sugge</strong>stions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:If you have any comments, suggestions, or feedback, please enter it below:</p>', '2022-09-09 10:51:15', '0', '2', NULL, '2022-09-12 06:56:04');

-- --------------------------------------------------------

--
-- Table structure for table `user_recruitment_forms`
--

DROP TABLE IF EXISTS `user_recruitment_forms`;
CREATE TABLE `user_recruitment_forms` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `your_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_joining` date DEFAULT NULL,
  `how_come_for_job_opening` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_employee_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_employee_designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_employee_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_of_your_recruiter` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `professionalism` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `friendliness` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `length_time_spent_talking` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `company_knowledge` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `specific_knowledge_job_profile` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `timely_response_email_phone` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `company_policies_procedures` enum('','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `manager_expectation_setting` enum('','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `job_duties_responsibilities` enum('','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `job_title_properly_named` enum('','Yes','No') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mission_for_first_year` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `aim_in_second_year` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `aim_third_year_tenure` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rate_overall_recruitment_process` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `additional_feedback_recruitment_process` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rate_hr_induction` enum('0','1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `additional_feedback_hr_induction` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `submitted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `user_recruitment_forms`
--

TRUNCATE TABLE `user_recruitment_forms`;
--
-- Dumping data for table `user_recruitment_forms`
--

INSERT INTO `user_recruitment_forms` (`id`, `user_id`, `your_name`, `member_id`, `designation`, `department`, `company_name`, `date_of_joining`, `how_come_for_job_opening`, `internal_employee_name`, `internal_employee_designation`, `internal_employee_department`, `name_of_your_recruiter`, `professionalism`, `friendliness`, `length_time_spent_talking`, `company_knowledge`, `specific_knowledge_job_profile`, `timely_response_email_phone`, `company_policies_procedures`, `manager_expectation_setting`, `job_duties_responsibilities`, `job_title_properly_named`, `mission_for_first_year`, `aim_in_second_year`, `aim_third_year_tenure`, `rate_overall_recruitment_process`, `additional_feedback_recruitment_process`, `rate_hr_induction`, `additional_feedback_hr_induction`, `submitted_date`, `is_deleted`, `status`, `created_at`, `updated_at`) VALUES
(1, 11, 'Athif Hussain', 'BVC2085', '10', '3', '1', '2021-10-26', '1', 'Gaurav Kumar', '10', '9', '40', '4', '2', '4', '4', '5', '4', 'Yes', 'No', 'No', 'No', '<p>What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?What will be your mission for the first year?</p>', '<p>What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?What do you aim in the second year?</p>', '<p>What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;What will be your aim in the third year of your tenure with us?&nbsp;</p>', '4', '<p>Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?Any additional feedback for the recruitment process?</p>', '5', '<p>Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?Any additional feedback for HR induction session?</p>', '2022-09-09 10:55:55', '0', '2', NULL, '2022-09-12 06:57:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_locations`
--
ALTER TABLE `company_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_names`
--
ALTER TABLE `company_names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirmation_feedback_forms`
--
ALTER TABLE `confirmation_feedback_forms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `confirmation_feedback_forms_user_id_foreign` (`user_id`),
  ADD KEY `confirmation_feedback_forms_manager_id_foreign` (`manager_id`);

--
-- Indexes for table `confirmation_generate_emails`
--
ALTER TABLE `confirmation_generate_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `confirmation_generate_emails_user_id_foreign` (`user_id`),
  ADD KEY `confirmation_generate_emails_updated_by_id_foreign` (`updated_by_id`);

--
-- Indexes for table `confirmation_moms`
--
ALTER TABLE `confirmation_moms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `confirmation_moms_user_id_foreign` (`user_id`),
  ADD KEY `confirmation_moms_manager_id_foreign` (`manager_id`);

--
-- Indexes for table `days_45_checkin_members`
--
ALTER TABLE `days_45_checkin_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `days_45_checkin_members_user_id_foreign` (`user_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `test2` (`company_id`);

--
-- Indexes for table `designations`
--
ALTER TABLE `designations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `test1` (`company_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fresh_eye_journals`
--
ALTER TABLE `fresh_eye_journals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fresh_eye_journals_user_id_foreign` (`user_id`);

--
-- Indexes for table `hiring_surveys`
--
ALTER TABLE `hiring_surveys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hiring_surveys_user_id_foreign` (`user_id`);

--
-- Indexes for table `job_opening_types`
--
ALTER TABLE `job_opening_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `letter_types`
--
ALTER TABLE `letter_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `letter_types_name_unique` (`name`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `place_yourself_categories`
--
ALTER TABLE `place_yourself_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `place_yourself_categories_name_unique` (`name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_surveys`
--
ALTER TABLE `training_surveys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `training_surveys_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `test` (`role_id`),
  ADD KEY `users_company_id_foreign` (`company_id`),
  ADD KEY `users_company_location_id_foreign` (`company_location_id`);

--
-- Indexes for table `user_interview_forms`
--
ALTER TABLE `user_interview_forms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_interview_forms_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_recruitment_forms`
--
ALTER TABLE `user_recruitment_forms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_recruitment_forms_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_locations`
--
ALTER TABLE `company_locations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_names`
--
ALTER TABLE `company_names`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `confirmation_feedback_forms`
--
ALTER TABLE `confirmation_feedback_forms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `confirmation_generate_emails`
--
ALTER TABLE `confirmation_generate_emails`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `confirmation_moms`
--
ALTER TABLE `confirmation_moms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `days_45_checkin_members`
--
ALTER TABLE `days_45_checkin_members`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `designations`
--
ALTER TABLE `designations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fresh_eye_journals`
--
ALTER TABLE `fresh_eye_journals`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hiring_surveys`
--
ALTER TABLE `hiring_surveys`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `job_opening_types`
--
ALTER TABLE `job_opening_types`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `letter_types`
--
ALTER TABLE `letter_types`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `place_yourself_categories`
--
ALTER TABLE `place_yourself_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `training_surveys`
--
ALTER TABLE `training_surveys`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `user_interview_forms`
--
ALTER TABLE `user_interview_forms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_recruitment_forms`
--
ALTER TABLE `user_recruitment_forms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `confirmation_feedback_forms`
--
ALTER TABLE `confirmation_feedback_forms`
  ADD CONSTRAINT `confirmation_feedback_forms_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `confirmation_feedback_forms_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `confirmation_generate_emails`
--
ALTER TABLE `confirmation_generate_emails`
  ADD CONSTRAINT `confirmation_generate_emails_updated_by_id_foreign` FOREIGN KEY (`updated_by_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `confirmation_generate_emails_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `confirmation_moms`
--
ALTER TABLE `confirmation_moms`
  ADD CONSTRAINT `confirmation_moms_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `confirmation_moms_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `days_45_checkin_members`
--
ALTER TABLE `days_45_checkin_members`
  ADD CONSTRAINT `days_45_checkin_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `test2` FOREIGN KEY (`company_id`) REFERENCES `company_names` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `designations`
--
ALTER TABLE `designations`
  ADD CONSTRAINT `test1` FOREIGN KEY (`company_id`) REFERENCES `company_names` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `fresh_eye_journals`
--
ALTER TABLE `fresh_eye_journals`
  ADD CONSTRAINT `fresh_eye_journals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `hiring_surveys`
--
ALTER TABLE `hiring_surveys`
  ADD CONSTRAINT `hiring_surveys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `training_surveys`
--
ALTER TABLE `training_surveys`
  ADD CONSTRAINT `training_surveys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `test` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `company_names` (`id`),
  ADD CONSTRAINT `users_company_location_id_foreign` FOREIGN KEY (`company_location_id`) REFERENCES `company_locations` (`id`);

--
-- Constraints for table `user_interview_forms`
--
ALTER TABLE `user_interview_forms`
  ADD CONSTRAINT `user_interview_forms_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
